<?php
/**
 * Personalización de la REST API para el frontend Astro.
 *
 *  - Expone cada metabox declarativa bajo la clave `croilab_<key>` (el
 *    framework Croilab_Meta ya lo registra).
 *  - Expone los campos legacy de proyectos (imagen_url, enlace_proyecto)
 *    para no romper la compatibilidad con el código actual.
 *  - Endpoint /croilab/v1/settings con la configuración global.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registra campos legacy de proyecto en la REST API.
 */
function croilab_content_legacy_rest_fields(): void {
	foreach ( array( 'enlace_proyecto', 'imagen_url' ) as $field ) {
		register_rest_field(
			'proyecto',
			$field,
			array(
				'get_callback' => function ( array $object ) use ( $field ) {
					$value = get_post_meta( (int) $object['id'], $field, true );
					return $value ?: '';
				},
				'schema' => array( 'type' => 'string' ),
			)
		);
	}
}
add_action( 'rest_api_init', 'croilab_content_legacy_rest_fields' );


/**
 * Endpoint para recibir leads desde el formulario del modal
 */
function croilab_content_register_lead_endpoint() {
	register_rest_route( 'croilab/v1', '/lead', array(
		'methods'             => 'POST',
		'callback'            => 'croilab_content_handle_lead_submission',
		'permission_callback' => '__return_true',
	) );
}
add_action( 'rest_api_init', 'croilab_content_register_lead_endpoint' );

function croilab_content_handle_lead_submission( WP_REST_Request $request ) {
	$params = $request->get_json_params();
	
	$nombre   = sanitize_text_field( $params['nombre'] ?? '' );
	$telefono = sanitize_text_field( $params['telefono'] ?? '' );
	$correo   = sanitize_email( $params['correo'] ?? '' );
	$servicio = sanitize_text_field( $params['servicio'] ?? '' );

	if ( empty( $nombre ) || empty( $correo ) ) {
		return new WP_Error( 'missing_fields', 'El nombre y correo son obligatorios.', array( 'status' => 400 ) );
	}

	$post_id = wp_insert_post( array(
		'post_type'    => 'lead',
		'post_title'   => $nombre . ' - ' . date('Y-m-d H:i'),
		'post_status'  => 'publish',
	) );

	if ( is_wp_error( $post_id ) ) {
		return new WP_Error( 'insert_failed', 'Error al guardar el lead.', array( 'status' => 500 ) );
	}

	update_post_meta( $post_id, 'lead_nombre', $nombre );
	update_post_meta( $post_id, 'lead_telefono', $telefono );
	update_post_meta( $post_id, 'lead_correo', $correo );
	update_post_meta( $post_id, 'lead_servicio', $servicio );

	return new WP_REST_Response( array( 'success' => true, 'message' => 'Lead guardado correctamente.' ), 200 );
}
